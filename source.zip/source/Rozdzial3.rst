Zakonczenie
===================

Dowolna Tresc
