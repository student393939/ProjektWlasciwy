Zakonczenie
============
Dowolna tresc
